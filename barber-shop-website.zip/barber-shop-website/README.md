# The Gentleman's Cut Barber Shop Website

A modern, professional React-based website for a premium barber shop. Built with Tailwind CSS and Framer Motion.
