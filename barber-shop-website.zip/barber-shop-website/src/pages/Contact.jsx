import React from 'react';

const Contact = () => {
  return (
    <section className="p-10">
      <h2 className="text-3xl font-semibold mb-6">Contact Us</h2>
      {/* Add form and contact details */}
    </section>
  );
};

export default Contact;