import React from 'react';

const About = () => {
  return (
    <section className="p-10">
      <h2 className="text-3xl font-semibold mb-6">About Us</h2>
      {/* Add team, story, and values */}
    </section>
  );
};

export default About;