import React from 'react';

const Services = () => {
  return (
    <section className="p-10">
      <h2 className="text-3xl font-semibold mb-6">Our Services</h2>
      {/* List services here */}
    </section>
  );
};

export default Services;