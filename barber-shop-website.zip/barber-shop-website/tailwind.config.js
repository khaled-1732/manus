module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        amber: '#FFC107',
        darkslate: '#1E1E1E',
      },
    },
  },
  plugins: [],
}